/* 
 * File:   Adp_micp_sensors.h
 * Author: Administrator
 *
 * Created on November 6, 2020, 8:53 PM
 */

#ifndef ADP_MICP_SENSORS_H
#define	ADP_MICP_SENSORS_H

#ifdef	__cplusplus
extern "C" {
#endif

void initSensor(void);
void Timing_calculation (void);


#ifdef	__cplusplus
}
#endif

#endif	/* ADP_MICP_SENSORS_H */

