/*
 * File:   Adp_micp_sensors_main.c
 * Author: Ming Wu
 *
 * Created on October 10, 2020, 9:23 PM
 */


#include "xc.h"
#include <stdint.h>
#include <math.h>
#include "wu000427_delay_asmLib.h"
#include "Adp_micp_sensors.h"


#pragma config POSCMOD = NONE      // Primary Oscillator Select (Primary oscillator disabled)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
#pragma config SOSCSEL = SOSC      // Sec Oscillator Select (Default Secondary Oscillator (SOSC))
#pragma config WUTSEL = LEG        // Wake-up timer Select (Legacy Wake-up Timer)
#pragma config IESO = ON           // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768     // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128       // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON         // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)
//#define abs(x) (x<0?-x:x)


//volatile int rollover = 0;
//int count=0;
//long int curTime_1 =0;
//long int curTime_2 =0;
//long int curTime_3 =0;
//double angle,angle_pervious = 0;
//int rotate;

void wait_n_ms(int delay){
    int i= delay;
    for(;i>0;i--){
        
        wait_1ms();
    }
}

void setup(){
    
    CLKDIVbits.RCDIV = 0;                        //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;                            //sets all pins to digital I/O
    TRISA &= 0xffff;                             
    TRISB |= 0x0070;                             //set RB4,RB5,RB6 to input
    
    //Timer2 setup
    _MI2C2IF = 0;
    I2C2CON = 0;                                 //disable I2C2
    I2C2BRG = 0x9d;                              //set Baud Rate 100kHz
    I2C2CONbits.I2CEN = 1;                       //enable I2C2
    
}


//void initSensor(){
//    
//    //Timer2 period = 0.001s
//    T2CON = 0x0000; //Stop Timer, Tcy clk source, PRE 1:1
//    TMR2 = 0;     // Initialize to zero
//    PR2 = 15999; 
//    _T2IF = 0;             //clear interrupt flag
//    _T2IE = 1;             //enable interrupt
//    T2CONbits.TON = 1; // Restart 16-bit Timer2
//    
//    
//    //set up IC         RB4 -> IC1  RB5 -> IC2
//    
//    __builtin_write_OSCCONL(OSCCON & 0xbf); // unlock PPS
//    RPINR7bits.IC1R = 4;  // Use Pin RP4 = "4", for Input Capture 1 
//    RPINR7bits.IC2R = 5;  // Use Pin RP5 for Input Capture 2
//    RPINR8bits.IC3R = 6;  // Use Pin RP6 for IC 3
//    __builtin_write_OSCCONL(OSCCON | 0x40); // lock   PPS
//    
//    
//    IC1CON = 0; // Turn off and reset internal state of IC1
//    IC1CONbits.ICTMR = 1; // Use Timer 2 for capture source
//    IC1CON = 1; // Interrupt on every capture event
//    IC1CONbits.ICM = 0b011; // Turn on and capture every rising edge
//    _IC1IE = 1; // Enable IC1 interrupts
//    
//    IC2CON = 0; // Turn off and reset internal state of IC2
//    IC2CONbits.ICTMR = 1; // Use Timer 2 for capture source
//    IC2CON = 1; // Interrupt on every capture event
//    IC2CONbits.ICM = 0b011; // Turn on and capture every rising edge
//    _IC2IE = 1; // Enable IC2 interrupts
//    
//    IC3CON = 0; // Turn off and reset internal state of IC3
//    IC3CONbits.ICTMR = 1; // Use Timer 2 for capture source
//    IC3CON = 1; // Interrupt on every capture event
//    IC3CONbits.ICM = 0b011; // Turn on and capture every rising edge
//    _IC3IE = 1; // Enable IC3 interrupts
//    
//    
//}
//
////Timer interrupt
//void __attribute__((interrupt, auto_psv)) _T2Interrupt(){      
//
//    rollover++;
//    _T2IF = 0;             //clear interrupt flag
//
//}
//
////IC1
//void __attribute__ ((interrupt, auto_psv)) _IC1Interrupt()
//{
//    
//    _IC1IF = 0; 
//    curTime_1 = TMR2 + (rollover * 16000);
//    count++;
//    
//    if (count == 3){
//        Timing_calculation();
//        count = 0;
//    }
//}
//
////IC 2
//void __attribute__ ((interrupt, auto_psv)) _IC2Interrupt(){
//    
//    _IC2IF = 0;
//    curTime_2 = TMR2 + (rollover * 16000);
//    count++;
//    
//    if (count == 3){
//        Timing_calculation();
//        count = 0;
//    }
//}
//
////IC3
//void __attribute__ ((interrupt, auto_psv)) _IC3Interrupt(){
//    
//    _IC3IF = 0;
//    curTime_3 = TMR2 + (rollover * 16000);
//    count++;
//    
//    if (count == 3){
//        Timing_calculation();
//        count = 0;
//    }
//}

//void Timing_calculation (){
//    
//    double X_test=-30;
//    double Y_test=-30;
//    double distant_1,distant_2,distant_3;
//    double D1_square,D2_square,D3_square;
//    double distant_diff_12,distant_diff_23,distant_diff_13;
//    long int Timediff_12,Timediff_23,Timediff_13;
//    double x=0,y=0;
//    long sum = 0,sum_mini = 1000000;
////    int check = 0;
//    
//    Timediff_12 = curTime_1 - curTime_2;
//    Timediff_23 = curTime_2 - curTime_3;
//    Timediff_13 = curTime_1 - curTime_3;
//    
//    //The unit of X,Y is 15 cm
//    //based on the speed of sound, 15 cm will have 7059 unit difference in Timer 2
//    //Test X from -30 to 30, Y from -30 to 30
//    //start with X = -30, Y = -30
//    while(Y_test <31){
//        
//         //finish test X range, Y++, go to test next X range
//        if(X_test ==30){
//            X_test = -30;
//            Y_test++;
//        }
//        
//        //calculate the distant from sound source to sensors
//        D1_square = (X_test * X_test) + (Y_test * Y_test);
//        distant_1 = sqrt(D1_square);
//        
//        D2_square = ((X_test + 1)*(X_test +1)) + (Y_test * Y_test);
//        distant_2 = sqrt(D2_square);
//        
//        D3_square = ((X_test +1)*(X_test +1)) + ((Y_test+1)*(Y_test+1));
//        distant_3 = sqrt(D3_square);
//        
//        //calculate the distance difference
//        distant_diff_12 = distant_1 - distant_2;
//        distant_diff_23 = distant_2 - distant_3;
//        distant_diff_13 = distant_1 - distant_3;
//        
//
//        sum = abs((distant_diff_12 * 7059 - Timediff_12)) + abs((distant_diff_23 * 7059 - Timediff_23)) + abs((distant_diff_13 * 7059 - Timediff_13));
//        
//        if (sum < sum_mini)
//        {
//            x = X_test;
//            y = Y_test;
//            sum_mini = sum;
//        }
//        
//        X_test++;
//    }
//    
//    //
//    //transfer location value to angle value
//    angle = atan (y/x) *180/3.1415;
//    
//    if(x < 0){
//        angle = 180 + angle;
//    }if(x > 0 & y < 0){
//        angle = angle + 360;
//    }
//    
//    //determine the rotation of motor
////    rotate = angle - angle_pervious;
//    
//    //only output when the change of angle greater than 5 degree
//    //so the microphone working more stable 
//    if (abs(angle - angle_pervious) > 5){
//    rotate = angle - angle_pervious;
//    angle_pervious = angle;
//    }else{
//        rotate = 0;
//    }
//    
//    
//    angle = 0;
//    
//    return 0;
//}


int main(void) {
    
    setup();
    initSensor(); 
    
             
    while(1){
         
        

    }
    
    return 0;
}
