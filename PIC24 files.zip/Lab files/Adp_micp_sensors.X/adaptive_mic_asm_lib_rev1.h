/* 
 * File:   adaptive_mic_asm_lib_rev1.h
 * Author: andrewkeech
 *
 * Created on February 3, 2019, 12:05 AM
 */

#ifndef ADAPTIVE_MIC_ASM_LIB_REV1_H
#define	ADAPTIVE_MIC_ASM_LIB_REV1_H

#ifdef	__cplusplus
extern "C" {
#endif
void delay_100us(void);
void delay_1ms(void);
#ifdef	__cplusplus
}
#endif

#endif