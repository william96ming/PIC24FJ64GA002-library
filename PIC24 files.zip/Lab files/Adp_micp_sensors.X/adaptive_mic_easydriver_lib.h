/* 
 * File:   adaptive_mic_easydriver_lib.h
 * Author: Administrator
 *
 * Created on November 11, 2020, 6:00 PM
 */

#ifndef ADAPTIVE_MIC_EASYDRIVER_LIB_H
#define	ADAPTIVE_MIC_EASYDRIVER_LIB_H

#ifdef	__cplusplus
extern "C" {
#endif

void delay(int delay_in_ms);
void setResolution(int res);
int angleToSteps(int angle);
void runCW(int steps);
void runCCW(int steps);


#ifdef	__cplusplus
}
#endif

#endif	/* ADAPTIVE_MIC_EASYDRIVER_LIB_H */

