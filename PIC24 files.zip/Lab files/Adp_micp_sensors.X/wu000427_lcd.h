/* 
 * File:   wu000427_lcd.h
 * Author: Administrator
 *
 * Created on July 20, 2020, 9:42 PM
 */

#ifndef WU000427_LCD_H
#define	WU000427_LCD_H

#ifdef	__cplusplus
extern "C" {
#endif

void lcd_cmd(char command);
void lcd_init(void);
void lcd_setCursor(char x, char y);
void lcd_printChar(char myChar);
void lcd_printStr(char s[]);


#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_LCD_H */

