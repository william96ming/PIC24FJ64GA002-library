#include "adaptive_mic_top.h"
#include "xc.h"


void delay(int delay_in_ms)
{
    while(delay_in_ms)
    {
        delay_1ms();
        delay_in_ms--;
    }
    
    
}

void setResolution(int res)
{
    if(res == 1)            // Full Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 2)       // Half Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 3)       // Quarter Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
    else if (res == 4)       // Eighth Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
        
}

int angleToSteps(int angle)
{
    int stepsFromAngle;
    double degPerStep = 1.8;
    stepsFromAngle = angle / degPerStep;
    return stepsFromAngle;
}



void runCW(int steps)
{
    
    LATBbits.LATB11 = 0;        // Set direction pin to turn motor CW
    LATBbits.LATB14 = 0;        // Enable the driver
    static int i;
    for(i = 0; i <steps; i = i+1)     // Repeat 200 times to make 1 full revolution in full step mode
            {
                delay_1ms();
                asm ("btg  LATB, #10");
                delay_1ms();
                asm ("btg  LATB, #10");
            }
    

}
void runCCW(int steps)
{
    LATBbits.LATB11 = 1;        // Set direction pin to turn motor CCW
    LATBbits.LATB14 = 0;        // Enable the driver
    static int j;
    for(j = 0; j <steps; j = j+1)     // Repeat 200 times to make 1 full revolution in full step mode
            {
                delay_1ms();
                asm ("btg  LATB, #10");
                delay_1ms();
                asm ("btg  LATB, #10");
            }

}