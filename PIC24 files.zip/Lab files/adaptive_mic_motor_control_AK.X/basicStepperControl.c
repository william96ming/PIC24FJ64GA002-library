/*
 * File:   basicStepperControl.c
 * Author: andyk
 *
 * Created on October 11, 2020, 9:54 AM
 */

#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)


// CW2: FLASH CONFIGURATION WORD 2 (see PIC24 Family Reference Manual 24.1)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator I/O Function (CLKO/RC15 functions as I/O pin)
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))



#include "xc.h"

void setup(void)
{
    CLKDIVbits.RCDIV = 0;  //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;            //Sets all(most) pins to digital I/O [1=digital, 0=analog]
    TRISA = 0b0000000000011111;  //Set port A to I/O (1 = input, 0 = output) 
    TRISB = 0b0000000000000011;  //Set port B to outputs (1 = intput, 0 = output)
    LATA = 0xffff;               //Set all of port A to HIGH
    LATB = 0xffff;               //and all of port B to HIGH    
}

void delay(void) 
{
    unsigned long int curCount = 333333;           //333333;     // TASK 3 - made curCount unsigned and long - Should be .25s, 
                                                // FORMULA: Cycles/Loop = 16 + (n-1)(12) + 15 ; ex. set delay = n; while delay, delay--
    while(curCount)
    {
        curCount--;
    }
}
/*PINOUT INFO
 * RB10: STEP
 * RB11: DIR
 * RB12: MS1
 * RB13: MS2
 * RB14: ENABLE
 * */
int main(void) 
{
    setup();
    
    while(1)
    {
        LATB = 0b1011001111111111;
        delay();
        LATBbits.LATB10 = 1;
        delay();
    }
   
    
    return 0;
}

