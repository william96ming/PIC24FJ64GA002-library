/*
 * File:   newmainXC16.c
 * Author: andyk
 *
 * Created on October 10, 2020, 10:35 PM
 */


#include "xc.h"

int main(void) {
    return 0;
}
