/*
 * File:   newmainXC16.c
 * Author: andyk
 *
 * Created on October 10, 2020, 10:35 PM
 */

// CW1: FLASH CONFIGURATION WORD 1 (see PIC24 Family Reference Manual 24.1)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)


// CW2: FLASH CONFIGURATION WORD 2 (see PIC24 Family Reference Manual 24.1)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator I/O Function (CLKO/RC15 functions as I/O pin)
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))



#include "xc.h"

/*PINOUT INFO
 * RB10: STEP
 * RB11: DIR
 * RB12: MS1
 * RB13: MS2
 * RB14: ENABLE
 * */

// 5ms timer to create pulse for step pin
void __attribute__((__interrupt__,__auto_psv__)) _T1Interrupt(void)
{
    int j = 0;
    //static int count = 0;
    for (j=0 ; j<5 ; j++)   // Since Timer 1 is 1ms, wait for five iterations of the timer for 5ms
        { 
            while (!_T1IF); // While waiting for the Timer 1 interrupt flag to go high, do nothing
            _T1IF = 0;      // Reset T1 interrupt flag after 1ms has passed, then return to 'for' loop and repeat 5 times total for 5ms pulse
            
        }
    asm ("btg  LATB, #10");         //Toggle RB10 (Step) every 5ms
    
}

void setResolution(int res)
{
    if(res == 1)            // Full Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 2)       // Half Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 3)       // Quarter Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
    else if (res == 4)       // Eighth Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
        
}
void stepCW(void)
{
    LATBbits.LATB11 = 0;    // Sets direction pin to 0, or forward (CW)
    LATBbits.LATB14 = 0;    // Enables motor

    TMR1 = 0;               // Reset Timer 1 to 0
    T1CONbits.TON = 1;      // now turn on the timer, should generate infinite pulse train w/ 10ms period
    
    
}

void setup(void)
{
    CLKDIVbits.RCDIV = 0;  //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;            //Sets all(most) pins to digital I/O [1=digital, 0=analog]
    TRISA = 0b0000000000011111;  //Set port A to I/O (1 = input, 0 = output) 
    TRISB = 0b0000000000000011;  //Set port B to outputs (1 = intput, 0 = output)
    LATA = 0xffff;               //Set all of port A to HIGH
    LATB = 0xffff;               //and all of port B to HIGH    
    
    
    // Timer 1 Setup
    T1CON = 0;              // turn off timer, prescalar 1:1, use Tcy = (1/Fcy) = 62.5ns as clk source
    PR1 = 15999;            // Value
    TMR1 = 0;
    _T1IF = 0;              // equivalent to IFS0bits.T1IF = 0;

}



int main(void) 
{
    setup();
    setResolution(4);
    stepCW();

    while(1)
    {
        asm ("nop");
    }
    return 0;
}
   
    
    

