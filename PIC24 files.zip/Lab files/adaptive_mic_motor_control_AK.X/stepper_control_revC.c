#include <p24Fxxxx.h>
#include <xc.h>
#include "adaptive_mic_asm_lib_rev1.h"

// PIC24FJ64GA002 Configuration Bit Settings
// CW1: FLASH CONFIGURATION WORD 1 (see PIC24 Family Reference Manual 24.1)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)


// CW2: FLASH CONFIGURATION WORD 2 (see PIC24 Family Reference Manual 24.1)
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator disabled. 
					// Primary Oscillator refers to an external osc connected to the OSC1 and OSC2 pins)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // OSC2/CLKO/RC15 functions as port I/O (RC15)
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))



// Function Declarations
void delay(int delay_in_ms);            // Based on 1ms delay in assembly library
void setResolution(int res);
int angleToSteps(int angle);
void runCW(int steps);
void runCCW(int steps);


/*PINOUT INFO
 * RB10: STEP
 * RB11: DIR
 * RB12: MS1
 * RB13: MS2
 * RB14: ENABLE
 * */



void setup(void) 
{
    CLKDIVbits.RCDIV = 0;

    AD1PCFG = 0x9fff;       // all digital except 14 and 13
    TRISB = 0x0077C;        // 5 inputs (RB2-RB6) from toggle switch (1s), 5 outputs (RB10-RB14) to stepper driver (0s). In binary, 0b0000_0000_0111_1100 
    LATB = 0;

}

int main(void) 
{
        setup();
        setResolution(1);
        int numSteps = 0;
        int angle = 0;
        unsigned int j;
       
        runCW(numSteps);        // Initialize to a 'zero' or home location corresponding with 0 degrees. Might need to incorporate limit switch in motor mount
        
        
        while(1)
        {
            angle = 45;

 
            numSteps = angleToSteps(angle);
            runCW(numSteps);
            for(j = 0; j<5000; j = j+1)
            {
                delay_1ms(); 
            }
            
            
            angle = 90;
            angleToSteps(angle);
            runCW(90);
            for(j = 0; j<5000; j = j+1)
            {
                delay_1ms(); 
            }
            delay(1000);        //Delay for 1 second
            
          
        }
        
            return 0;
        
               
}













/*****************************************************************************
*    Function:  delay()
*  Parameters:  int delay_in_ms - Integer value of desired delay in milliseconds
*      Return:  Nothing
* Description:  Calls the 1ms delay a number of times specified by the user                                  
*****************************************************************************/
void delay(int delay_in_ms)
{
    while(delay_in_ms)
    {
        delay_1ms();
        delay_in_ms--;
    }
    
    
}


void getAngle(void)
{
    
}

void setResolution(int res)
{
    if(res == 1)            // Full Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 2)       // Half Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 0;  //MS2
    }
    else if(res == 3)       // Quarter Stepping
    {
        LATBbits.LATB12 = 0;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
    else if (res == 4)       // Eighth Stepping
    {
        LATBbits.LATB12 = 1;  //MS1
        LATBbits.LATB13 = 1;  //MS2
    }
        
}
int angleToSteps(int angle)
{
    double stepsPerRev = 1.8;
    int stepsFromAngle;
    stepsFromAngle = angle / stepsPerRev;
    return stepsFromAngle;
}



void runCW(int steps)
{
    
    LATBbits.LATB11 = 0;        // Set direction pin to turn motor CW
    LATBbits.LATB14 = 0;        // Enable the driver
    static int i;
    for(i = 0; i <steps; i = i+1)     // Repeat 200 times to make 1 full revolution in full step mode
            {
                delay_1ms();
                asm ("btg  LATB, #10");
                delay_1ms();
                asm ("btg  LATB, #10");
            }
    

}
void runCCW(int steps)
{
    LATBbits.LATB11 = 1;        // Set direction pin to turn motor CCW
    LATBbits.LATB14 = 0;        // Enable the driver
    static int j;
    for(j = 0; j <steps; j = j+1)     // Repeat 200 times to make 1 full revolution in full step mode
            {
                delay_1ms();
                asm ("btg  LATB, #10");
                delay_1ms();
                asm ("btg  LATB, #10");
            }

}