/* 
 * File:   sample.h
 * Author: Administrator
 *
 * Created on July 17, 2020, 9:46 PM
 */

#ifndef SAMPLE_H
#define	SAMPLE_H

#ifdef	__cplusplus
extern "C" {
#endif

    void loop(void);


#ifdef	__cplusplus
}
#endif

#endif	/* SAMPLE_H */

