/*
 * File:   sample_main.c
 * Author: Administrator
 *
 * Created on July 17, 2020, 9:45 PM
 */


#include "xc.h"
#include "sample.h"

int main(void) {
    return 0;
}
