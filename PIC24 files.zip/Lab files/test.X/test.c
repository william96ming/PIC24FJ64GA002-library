/*
 * File:   test.c
 * Author: Administrator
 *
 * Created on July 2, 2020, 9:34 AM
 */


#include "xc.h"

void setup(){

}

int main(){
    setup();

    
}
