/* 
 * File:   wu000427_lab2b_asmLib_v001.h
 * Author: Administrator
 *
 * Created on June 16, 2020, 8:45 PM
 */

#ifndef WU000427_LAB2B_ASMLIB_V001_H
#define	WU000427_LAB2B_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif
    
void wait_50us(void);
void wait_1ms(void);
void write_0(void);
void write_1(void);
  

#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_LAB2B_ASMLIB_V001_H */

