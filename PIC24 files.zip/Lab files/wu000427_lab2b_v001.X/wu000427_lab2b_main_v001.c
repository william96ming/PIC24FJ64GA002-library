  #include "xc.h"
  #include "wu000427_lab2b_asmLib_v001.h"
  
  // CONFIG0
  #pragma config POSCMOD = NONE      // Primary Oscillator Select (Primary oscillator disabled)
  #pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
  #pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
  #pragma config OSCIOFNC = ON       // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
  #pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                         // Fail-Safe Clock Monitor is enabled)
  #pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
  #pragma config SOSCSEL = SOSC      // Sec Oscillator Select (Default Secondary Oscillator (SOSC))
  #pragma config WUTSEL = LEG        // Wake-up timer Select (Legacy Wake-up Timer)
  #pragma config IESO = ON           // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)
  
  // CONFIG1
  #pragma config WDTPS = PS32768     // Watchdog Timer Postscaler (1:32,768)
  #pragma config FWPSA = PR128       // WDT Prescaler (Prescaler ratio of 1:128)
  #pragma config WINDIS = ON         // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
  #pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
  #pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
  #pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
  #pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
  #pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)
  
  
  void setup(void){
      
      CLKDIVbits.RCDIV = 0;       //bclr    CLKDIV,#8      clear 8 bit in CLKDIV
      AD1PCFG = 0x9FFF;
      TRISA = 0b1111111111111110;
      LATA = 0x0000;
      
  }
  
  void writeColor(int r, int g, int b){
      int i;
      unsigned char x;
      
      for(i=0;i<8;i++){
      x = (r<<i)&(1<<7);        
      if ( x == 0){
          write_0();
      }else{
          write_1();
      }}
      
      for(i=0;i<8;i++){
          
      x = (g<<i)&(1<<7);        
      if ( x == 0){
          write_0();
      }else{
          write_1();
      }}
          
      for(i=0;i<8;i++){
          
      x = (b<<i)&(1<<7);        
      if ( x == 0){
          write_0();
      }else{
          write_1();
      }}
      wait_50us();
      wait_50us();
  }
  
  void delay_n_ms(int delay){
      int i = delay;
      for (i; i >0 ;i--){
          wait_1ms();
      }
  }
  void Color_change (){
      unsigned char byteFramNumber;
          
     for (byteFramNumber = 255; byteFramNumber--;byteFramNumber >-1 ){
          
      unsigned char r = byteFramNumber;
      unsigned char g = 0;
      unsigned char b = 255-byteFramNumber;  
      writeColor(r,g,b);
      delay_n_ms(5);
      }  
      
  
      
      for (byteFramNumber = 0; ++byteFramNumber ;byteFramNumber <256 ){
          
      unsigned char r = byteFramNumber;
    unsigned char g = 0;
     unsigned char b = 255-byteFramNumber;
     writeColor(r,g,b);
     delay_n_ms(5);
     }}    
 
  unsigned long int packColor (unsigned char r, unsigned char g, unsigned char b){
   
     unsigned long int RGBval;
     
     RGBval  = (((long)r<<16)|((long)g<<8)|((long)b)); 
      
      return RGBval;
 }
  
  unsigned char getR( unsigned long int RGBval)
  {
     unsigned char r;
      r = (unsigned char)(RGBval>>16);
      
    return r;
  
  }
  
  unsigned char getG( unsigned long int RGBval)
  {
     unsigned char g;
     g = (unsigned char)(RGBval>>8);
      
    return g;
       
  }
  
  unsigned char getB( unsigned long int  RGBval)
  {
     unsigned char b;
     b = (unsigned char)(RGBval);
      
    return b;
  
  }
 
  void writePackCol(unsigned long int RGBval){
      
      long r,g,b;
         
      r = getR(RGBval);
      g = getG(RGBval);
      b = getB(RGBval);
      
      writeColor(r,g,b);
          
  }
 
  
 void wheel(unsigned char wheelpos){
    
      unsigned long int RGBval=0;
      unsigned char r;
      unsigned char g;
      unsigned char b;
     
    wheelpos = 255 - wheelpos;
    
     if (wheelpos < 85){
         r = 255-wheelpos*3;
         g = 0;
         b = wheelpos*3;
     }
     if (wheelpos < 170){
         r = 0;
         g = wheelpos*3;
        b = 255-wheelpos*3;        
    }
     if (wheelpos >= 170){
         r = wheelpos*3;
        g = 255-wheelpos*3;
         b =0;
         }
     
      RGBval = packColor (r,g,b);         //packing color
      
     writePackCol (RGBval);   //display color
     
 }




 int main(void) {
     setup();
  
     while(1)
     {
     //writeColor(0,255,0);        //part1
     //Color_change( );           //part 2

 //   int w;
 //    for(w=0; ++w ; w<256){
 //         
 //        wheel(w);
 //         delay_n_ms(5);
 //    }   
       
     }
 
     return 0;
 }
