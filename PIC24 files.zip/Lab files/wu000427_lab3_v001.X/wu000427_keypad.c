#include "xc.h"
#include "stdint.h"
#include "wu000427_lab3_asmLib_v001.h"

void initkeypad(){    
    
    TRISA|= 0x000f;     //set RA[0:3]to input
    TRISB&= 0x0fff;     //set RB[15:12]to output
                        //enable internal pull-up resistor for RA[0:3]
    CNPU1bits.CN2PUE = 1;     //CN2,CN3
    CNPU1bits.CN3PUE = 1;
     
    CNPU2bits.CN29PUE = 1;     //CN29,CN30   
    CNPU2bits.CN30PUE = 1;

}       //set up I/O, pull-up resistors

char readKeyPadROW (){
                        
    LATB |= 0xf000;         //check first row   RB12=0
    LATB &= 0xefff;
    wait_50us();        
    switch (PORTA & 0x000f){
    case 0x0007:return('1');
	case 0x000b:return('2');
	case 0x000d:return('3');
	case 0x000e:return('a');
    }
                        //check second row RB13=0
    LATB |= 0xf000;
    LATB &= 0xdfff;
    wait_50us();
    switch (PORTA & 0x000f){
    case 0x0007:return('4');
	case 0x000b:return('5');
	case 0x000d:return('6');
	case 0x000e:return('b');
    }
    
    LATB = LATB | 0xf000;
	LATB = LATB & 0xbfff;
    wait_50us();
	switch (PORTA & 0x000f)
	{
	case 0x0007:return('7');
	case 0x000b:return('8');
	case 0x000d:return('9');
	case 0x000e:return('c');
	}
    
    LATB = LATB | 0xf000;
	LATB = LATB & 0x7fff;
    wait_50us();
	switch (PORTA & 0x000f)
	{
	case 0x0007:return('e');
	case 0x000b:return('0');
	case 0x000d:return('f');
	case 0x000e:return('d');
	}    
    return ('x');
    
}

