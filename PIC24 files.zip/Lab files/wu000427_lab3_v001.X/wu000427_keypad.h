/* 
 * File:   wu000427_keypad.h
 * Author: Administrator
 *
 * Created on June 30, 2020, 12:59 PM
 */

#ifndef WU000427_KEYPAD_H
#define	WU000427_KEYPAD_H

#ifdef	__cplusplus
extern "C" {
#endif

void initkeypad(void);
char readKeyPadROW (void);

#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_KEYPAD_H */

