#include "xc.h"
#include "stdint.h"


void init7seg(){
    
    TRISB &= 0xf003;           //port B [2:11] output
    
}


void showChar7seg(char chr, int right)      //show character in screen
{
	LATB = LATB | 0x0c00;      // RB11, RB10 = 1	
    LATB = LATB | 0x03fc;       
	if (right)                 
		LATB = LATB & 0xfbff;
	else
		LATB = LATB & 0xf7ff;


	switch (chr)
	{
	case '0':
		LATB = LATB & 0xfc0f;
		break;
	case '1':
		LATB = LATB & 0xfe7f;
		break;
	case '2':
		LATB = LATB & 0xfc97;
		break;
	case '3':
		LATB = LATB & 0xfc37;
		break;
	case '4':
		LATB = LATB & 0xfe67;
		break;
	case '5':
		LATB = LATB & 0xfd27;
		break;
	case '6':
		LATB = LATB & 0xfd07;
		break;
	case '7':
		LATB = LATB & 0xfc6f;
		break;
	case '8':
		LATB = LATB & 0xfc07;
		break;
	case '9':
		LATB = LATB & 0xfc27;
		break;
	case 'a':
		LATB = LATB & 0xfc47;
		break;
	case 'b':
		LATB = LATB & 0xff07;
		break;
	case 'c':
		LATB = LATB & 0xfd8f;
		break;
	case 'd':
		LATB = LATB & 0xfe17;
		break;
	case 'e':
		LATB = LATB & 0xfd87;
		break;
	case 'f':
		LATB = LATB & 0xfdc7;
		break;
	case 'x':                       // for debug
		break;
	}
}

