/* 
 * File:   wu000427_sevSegDisp.h
 * Author: Administrator
 *
 * Created on June 30, 2020, 12:53 PM
 */

#ifndef WU000427_SEVSEGDISP_H
#define	WU000427_SEVSEGDISP_H

#ifdef	__cplusplus
extern "C" {
#endif
    
void init7seg(void);
void showChar7seg(char myChar, int myDigit);



#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_SEVSEGDISP_H */

