#include "xc.h"

unsigned int Capture1, Capture2;

void initPushButton(){
    
    //Timer2 periode=1s
    T2CON = 0x0030; //Stop Timer, Tcy clk source, PRE 1:256
    TMR2 = 0;     // Initialize to zero
    PR2 = 62499; 
    _T2IF = 0;             //clear interrupt flag
    _T2IE = 1;             //enable interrupt
    T2CONbits.TON = 1; // Restart 16-bit Timer2
    
    CNPU2bits.CN22PUE = 1;      //turn on the pull-up resistor RB8
    TRISBbits.TRISB8 = 1;       //RB8 input
    
    //set up IC 1
    
    __builtin_write_OSCCONL(OSCCON & 0xbf); // unlock PPS
    RPINR7bits.IC1R = 8;  // Use Pin RP8 = "8", for Input Capture 1 
    __builtin_write_OSCCONL(OSCCON | 0x40); // lock   PPS
    
    
    IC1CON = 0; // Turn off and reset internal state of IC1
    IC1CONbits.ICTMR = 1; // Use Timer 2 for capture source
    IC1CON = 1; // Interrupt on every capture event
    IC1CONbits.ICM = 0b010; // Turn on and capture every falling edge
    _IC1IE = 1; // Enable IC1 interrupts
    
    
}

