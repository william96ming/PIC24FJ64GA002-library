/* 
 * File:   PushButton.h
 * Author: Administrator
 *
 * Created on July 6, 2020, 5:17 AM
 */

#ifndef PUSHBUTTON_H
#define	PUSHBUTTON_H

#ifdef	__cplusplus
extern "C" {
#endif

void initPushButton(void);


#ifdef	__cplusplus
}
#endif

#endif	/* PUSHBUTTON_H */

