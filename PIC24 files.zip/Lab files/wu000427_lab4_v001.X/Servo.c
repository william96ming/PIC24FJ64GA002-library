#include "xc.h"

void initServo(){
    
   
//utilizes PPS to bind Output Compare 1 to RP6/RB6
    __builtin_write_OSCCONL(OSCCON & 0xbf);      // unlock PPS
    RPOR3bits.RP6R = 18;                         // Use Pin RP6 for Output Compare 1 = "18"
    __builtin_write_OSCCONL(OSCCON | 0x40);      // lock   PPS
    
//Configure Timer 3 with 20 ms period(320000 cycles)
    T3CON = 0x0030;                               //Stop Timer, Tcy clk source, PRE 1:256
    TMR3 = 0;                                     // Initialize to zero
    PR3 = 1249;                                   //1249+1
    T3CON |=0x8000;
    
//OC1 Core Registers
    OC1CON = 0;                                     // turn off OC1 for now
    OC1R = 0;                                    // servo start position. We won?t touch OC1R again
    OC1RS = 0;                                   // We will only change this once PWM is turned on
    OC1CONbits.OCTSEL = 1;                          // Use Timer 3 for compare source
    OC1CONbits.OCM = 0b110;                         // Output compare PWM w/o faults
    
}

void setServo(int Val)
{
    OC1RS = Val;                  
}