void setup(){
    AD1PCFG = 0x9fff;
    TRISA = 0x0003;     //RA 0,1 input
    TRISB = 0xfffc;     //RB0,1 output
}

int main(void){
    setup();
    while(1){
        switch(PORTA & 0x0003){
            case 0x0001:LATB = 0x0001;
            case 0x0002:LATB = 0x0002;
            case 0x0003:LATB = 0x0000;
            case 0x0000:LATB = 0x0000;
        }
        
    }
    
}
