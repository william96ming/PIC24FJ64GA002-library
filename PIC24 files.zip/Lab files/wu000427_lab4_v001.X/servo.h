/* 
 * File:   servo.h
 * Author: Administrator
 *
 * Created on July 6, 2020, 5:14 AM
 */

#ifndef SERVO_H
#define	SERVO_H

#ifdef	__cplusplus
extern "C" {
#endif

void initServo(void);
void setServo(int Val);


#ifdef	__cplusplus
}
#endif

#endif	/* SERVO_H */

