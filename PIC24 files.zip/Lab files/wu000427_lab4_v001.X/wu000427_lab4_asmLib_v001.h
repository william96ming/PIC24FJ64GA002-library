/* 
 * File:   wu000427_lab4_asmLib_v001.h
 * Author: Administrator
 *
 * Created on July 2, 2020, 7:57 AM
 */

#ifndef WU000427_LAB4_ASMLIB_V001_H
#define	WU000427_LAB4_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif

void wait_1ms(void);


#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_LAB4_ASMLIB_V001_H */

