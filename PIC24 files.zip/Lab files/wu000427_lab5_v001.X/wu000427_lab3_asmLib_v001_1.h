/* 
 * File:   wu000427_lab3_asmLib_v001.h
 * Author: Administrator
 *
 * Created on June 23, 2020, 2:36 AM
 */

#ifndef WU000427_LAB5_ASMLIB_V001_H
#define	WU000427_LAB5_ASMLIB_V001_H

#ifdef	__cplusplus
extern "C" {
#endif

void wait_1ms(void);

#ifdef	__cplusplus
}
#endif

#endif	/* WU000427_LAB3_ASMLIB_V001_H */

