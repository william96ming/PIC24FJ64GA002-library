/*
 * File:   wu000427_lab5_main_v001.c
 * Author: Administrator
 *
 * Created on July 15, 2020, 6:44 PM
 */


#include "xc.h"
#include <stdint.h>
#include "wu000427_lcd.h"
#include "wu000427_lab5_asmLib_v001.h"

#pragma config POSCMOD = NONE      // Primary Oscillator Select (Primary oscillator disabled)
#pragma config I2C1SEL = PRI       // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF       // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = ON       // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as port I/O (RC15))
#pragma config FCKSM = CSECME      // Clock Switching and Monitor (Clock switching is enabled, 
                                       // Fail-Safe Clock Monitor is enabled)
#pragma config FNOSC = FRCPLL      // Oscillator Select (Fast RC Oscillator with PLL module (FRCPLL))
#pragma config SOSCSEL = SOSC      // Sec Oscillator Select (Default Secondary Oscillator (SOSC))
#pragma config WUTSEL = LEG        // Wake-up timer Select (Legacy Wake-up Timer)
#pragma config IESO = ON           // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) enabled)

// CONFIG1
#pragma config WDTPS = PS32768     // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128       // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = ON         // Watchdog Timer Window (Standard Watchdog Timer enabled,(Windowed-mode is disabled))
#pragma config FWDTEN = OFF        // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx1          // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config GWRP = OFF          // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF           // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF        // JTAG Port Enable (JTAG port is disabled)

int ADCvalue = 0;

void wait_n_ms(int delay){
    int i= delay;
    for(;i>0;i--){
        
        wait_1ms();
    }
}

void setup(){
    
    CLKDIVbits.RCDIV = 0;                        //Set RCDIV=1:1 (default 2:1) 32MHz or FCY/2=16M
    AD1PCFG = 0x9fff;                            //sets all pins to digital I/O
    TRISA &= 0xfffe;                             //set RA0 to output
    
    _MI2C2IF = 0;
    I2C2CON = 0;                                 //disable I2C2
    I2C2BRG = 0x9d;                              //set Baud Rate 100kHz
    I2C2CONbits.I2CEN = 1;                       //enable I2C2
    
}

int main(void) {
    
    setup();
    lcd_init();    
    int i=0;
    i = ~i;
    
    int ADCValue;AD1PCFG = 0xFFFE;        // AN0 as analog, all other pins are digital
    AD1CON1 = 0x0100;                     // SAMP bit = 0 ends sampling and starts converting
    AD1CHS  = 0x0000;                     // Connect AN0 as S/H+ input
                                          // in this example AN0 is the input
    AD1CSSL = 0;
    AD1CON3 = 0x0002;                     // Manual Sample, Tad = 3Tcy
    AD1CON2 = 0;
    AD1CON1bits.ADON = 1;                  // turn ADC ON
                   
    while(1){
        AD1CON1bits.SAMP = 1;              // start sampling...
        wait_n_ms(1);                   // Ensure the correct sampling time has elapsed
        // before starting conversion.
        AD1CON1bits.SAMP = 0;              // start converting
        while (!AD1CON1bits.DONE){};      // conversion done?
        ADCValue = ADC1BUF0;              // yes then get ADC value
        ADCValue &= 0x01ff;
        lcd_setCursor(0,0);
        if(ADCValue == 0){
            lcd_printStr("0 mA");
        }if(ADCValue > 0 && ADCValue <= 1){
            lcd_printStr("5 mA");
            wait_n_ms(2000); 
        }if(ADCValue > 50 && ADCValue <= 2){
            lcd_printStr("10mA");
            wait_n_ms(2000); 
        }if(ADCValue > 90 && ADCValue <= 15){
            lcd_printStr("15mA");
            wait_n_ms(2000); 
        }if(ADCValue<0 | ADCValue >15){
            lcd_printStr("0");
        }
        
    }
    
    return 0;
}
